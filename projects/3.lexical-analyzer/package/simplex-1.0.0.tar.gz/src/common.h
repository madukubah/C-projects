#ifndef simplex_common_h
#define simplex_common_h

//#define DEBUG_MODE

#endif
