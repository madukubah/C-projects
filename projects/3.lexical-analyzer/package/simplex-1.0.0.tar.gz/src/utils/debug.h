#ifndef simplex_debug_h
#define simplex_debug_h

#include "parser.h"

void printOpList(OperationList opList);

#endif