#ifndef simplex_dfa_h
#define simplex_dfa_h

int dfaMatch(const char *str, const char *regex);

#endif